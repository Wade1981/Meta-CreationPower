# ELR Container Installer

## Installation Instructions

1. Extract this zip file to your desired location
2. Run `install.bat` from the extracted directory
3. Follow the prompts to complete the installation
4. Use the `elr` command from anywhere in your terminal

## System Requirements
- Windows 10 or later
- PowerShell 5.1 or later
- Python 3.8+ (optional, for running Python scripts)
- GCC (optional, for compiling C programs)

## Usage

After installation, you can use the `elr` command to interact with ELR:

### Basic Commands
- `elr start` - Start the ELR runtime
- `elr stop` - Stop the ELR runtime
- `elr status` - Check runtime status
- `elr list` - List all containers
- `elr help` - Show help information

### Advanced Commands
- `elr create --name <name> --image <image>` - Create a new container
- `elr run --name <name> --image <image>` - Create and start a new container
- `elr start-container --id <container-id>` - Start a container
- `elr stop-container --id <container-id>` - Stop a container
- `elr delete --id <container-id>` - Delete a container
- `elr exec --id <container-id> --command <command>` - Execute a command in a container

### Model Commands
- `elr run-python --source <script.py>` - Run a Python script
- `elr run-python --code '<python code>'` - Run Python code directly
- `elr chat` - Start interactive chat with default local model
- `elr chat --model <model.py>` - Start chat with custom model

## Troubleshooting

### Python Not Found
If you encounter Python-related errors, ensure Python 3.8+ is installed and in your PATH.

### GCC Not Found
If you need to compile C programs, install GCC through one of these methods:
- MinGW-w64: https://www.mingw-w64.org/
- MSYS2: https://www.msys2.org/
- Cygwin: https://www.cygwin.com/

### Network Issues
If you have network connectivity issues, check your firewall settings and ensure you can access GitHub.

## Updates
To update ELR, simply download the latest installer and run it again.
