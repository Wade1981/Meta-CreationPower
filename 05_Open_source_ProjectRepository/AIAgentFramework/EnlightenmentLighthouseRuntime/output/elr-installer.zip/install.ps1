# ELR Container Installer
# Zip archive installation script

param(
    [string]$InstallDir = "$env:USERPROFILE\ELR"
)

Write-Host "===================================="
Write-Host "Enlightenment Lighthouse Runtime (ELR)"
Write-Host "Installation Script"
Write-Host "===================================="

# Function to create directory if it doesn't exist
function Ensure-DirectoryExists {
    param([string]$directory)
    if (-not (Test-Path $directory)) {
        Write-Host "Creating directory: $directory"
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
}

# Function to add directory to PATH
function Add-ToPath {
    param([string]$directory)
    $path = [Environment]::GetEnvironmentVariable("PATH", "User")
    if ($path -notlike "*$directory*") {
        Write-Host "Adding $directory to PATH"
        $newPath = "$path;$directory"
        [Environment]::SetEnvironmentVariable("PATH", $newPath, "User")
        Write-Host "PATH updated. You may need to restart your terminal for changes to take effect."
    } else {
        Write-Host "$directory is already in PATH"
    }
}

# Main installation process
try {
    # Get installation directory from user if not provided
    if (-not $InstallDir) {
        $InstallDir = Read-Host "Enter installation directory (default: $env:USERPROFILE\ELR)"
        if ([string]::IsNullOrEmpty($InstallDir)) {
            $InstallDir = "$env:USERPROFILE\ELR"
        }
    }
ECHO ���ڹر�״̬��
    # Create installation directory
    Ensure-DirectoryExists $InstallDir
ECHO ���ڹر�״̬��
    # Create subdirectories
    $binDir = Join-Path $InstallDir "bin"
    $libDir = Join-Path $InstallDir "lib"
    $configDir = Join-Path $InstallDir "config"
    $modelsDir = Join-Path $InstallDir "models"
    $containersDir = Join-Path $InstallDir "containers"
ECHO ���ڹر�״̬��
    Ensure-DirectoryExists $binDir
    Ensure-DirectoryExists $libDir
    Ensure-DirectoryExists $configDir
    Ensure-DirectoryExists $modelsDir
    Ensure-DirectoryExists $containersDir
ECHO ���ڹر�״̬��
    # Copy files from current directory
    $currentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    Write-Host "Copying ELR files from $currentDir to $InstallDir"
ECHO ���ڹر�״̬��
    # Copy main ELR scripts
    Copy-Item "$currentDir\bin\*" $binDir -Force
    Write-Host "Copied bin files"
ECHO ���ڹر�״̬��
    # Copy micro_model directory
    Copy-Item "$currentDir\lib\*" $libDir -Recurse -Force
    Write-Host "Copied lib files"
ECHO ���ڹر�״̬��
    # Copy models directory
    Copy-Item "$currentDir\models\*" $modelsDir -Recurse -Force
    Write-Host "Copied models"
ECHO ���ڹر�״̬��
    # Add bin directory to PATH
    Add-ToPath $binDir
ECHO ���ڹر�״̬��
    # Create a README file
    $readmeContent = '# Enlightenment Lighthouse Runtime (ELR)

## Installation
ELR has been successfully installed to: $InstallDir

## Usage

### Basic Commands
- `elr start` - Start the ELR runtime
- `elr stop` - Stop the ELR runtime
- `elr status` - Check runtime status
- `elr list` - List all containers
- `elr help` - Show help information

### Advanced Commands
- `elr create --name <name> --image <image>` - Create a new container
- `elr run --name <name> --image <image>` - Create and start a new container
- `elr start-container --id <container-id>` - Start a container
- `elr stop-container --id <container-id>` - Stop a container
- `elr delete --id <container-id>` - Delete a container
- `elr exec --id <container-id> --command <command>` - Execute a command in a container

### Model Commands
- `elr run-python --source <script.py>` - Run a Python script
- `elr run-python --code '<python code>'` - Run Python code directly
- `elr chat` - Start interactive chat with default local model
- `elr chat --model <model.py>` - Start chat with custom model

## Configuration
Configuration files are stored in: $configDir

## Models
Model files are stored in: $modelsDir

## Containers
Container data is stored in: $containersDir

## Troubleshooting
- If you encounter issues with Python, ensure Python 3.8+ is installed and in PATH
- If you encounter issues with C compilation, ensure GCC is installed
- For network issues, check your firewall settings

## Updates
To update ELR, simply run the installer again with the latest version.'
ECHO ���ڹر�״̬��
    $readmePath = Join-Path $InstallDir "README.md"
    $readmeContent | Set-Content $readmePath -Force
    Write-Host "Created README.md"
ECHO ���ڹر�״̬��
    # Test the installation
    Write-Host "===================================="
    Write-Host "Testing ELR installation..."
    Write-Host "===================================="
ECHO ���ڹر�״̬��
    # Change to installation directory and test
    Push-Location $InstallDir
    try {
        # Test ELR version
        Write-Host "Testing ELR version..."
-File ��ʽ������ʵ�ʲ�����$binDir\elr.ps1�������ڡ����ṩ���С�.ps1���ļ���·������Ϊ -File ��ʽ������һ��ʵ�ʲ�����
Windows PowerShell
��Ȩ���� (C) Microsoft Corporation����������Ȩ����

�����µĿ�ƽ̨ PowerShell https://aka.ms/pscore6

ECHO ���ڹر�״̬��
        # Test ELR help
        Write-Host "\nTesting ELR help..."
-File ��ʽ������ʵ�ʲ�����$binDir\elr.ps1�������ڡ����ṩ���С�.ps1���ļ���·������Ϊ -File ��ʽ������һ��ʵ�ʲ�����
Windows PowerShell
��Ȩ���� (C) Microsoft Corporation����������Ȩ����

�����µĿ�ƽ̨ PowerShell https://aka.ms/pscore6

    } finally {
        Pop-Location
    }
ECHO ���ڹر�״̬��
    Write-Host "===================================="
    Write-Host "ELR installation completed successfully!"
    Write-Host "===================================="
    Write-Host "Installation directory: $InstallDir"
    Write-Host "Binary directory: $binDir"
    Write-Host ""
    Write-Host "You can now use 'elr' command from anywhere in your terminal."
    Write-Host "Example: elr start"
    Write-Host ""
    Write-Host "For more information, see the README.md file in the installation directory."
ECHO ���ڹر�״̬��
    # Pause to allow user to see the output
    Read-Host "Press Enter to exit..."
ECHO ���ڹر�״̬��
} catch {
    Write-Host "Error during installation: $_"
    Read-Host "Press Enter to exit..."
    exit 
}
